DS1scene, v 0.61   beta     05/25/2002        Paul SIRAMY
================

This program was primilary built for debuging purpose, so don't expect too
much from it.

First, you have to extract all the ds1 and dt1 there are in your mpq. I
recomand to use "MPQ Stormless Editor" at http://www.angelfire.com/sc/mpq/
since you can extract all of that with all the sub-directories in just
a right-cick of your mouse. Take d2data.mpq, and extract all the ds1 and
the dt1 somewhere on your disk. Then do the same for d2exp.mpq, then
again for patch_d2.mpq (in case there are some ds1 in it). This order is
important : the new ones need to erase the old ones.

Then, edit the ds1scene.ini and modify the "tiles_path" line to point to
your tiles directory. Now, just launch some .bat : you'll get the pcx.

If you want to make another bitmap, copy and rename a bat, and edit it.
here are the description of the parameters :
 * name of the pcx the bitmap will be save
 * the ds1 you want to draw in geant bitmap
      warning : don't use full path, just from the tiles path
 * in dt1files.txt, the number you find in the Id column
 * in dt1mask.txt, the number you find in the Def column
   Take duriel.bat and check in this 2 txt, you might understand, it's easy.
 * a mask for the drawing of layers. 0=don't draw, 1=draw it
   (check _fortress.bat)

There are still some minor problems in some ds1, but not many.

The debug_txt\*.txt are for debuging purpose. It's info from the ds1
interpreted by the ds1scene.exe.

I'll be happy if you give me the bad results of your test. If you do this,
give me the command line you have used (the one in the .bat).

Now it's time to make giant pcx.
