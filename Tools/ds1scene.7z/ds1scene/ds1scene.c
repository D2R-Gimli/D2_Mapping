#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mem.h>
#include <dir.h>

#include <allegro.h>

#define WORD  short int
#define UBYTE unsigned char

#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE -1
#endif

// reducing size of executable, for the allegro 3.9.34 (wip) lib

BEGIN_COLOR_DEPTH_LIST
   COLOR_DEPTH_8
END_COLOR_DEPTH_LIST

BEGIN_MIDI_DRIVER_LIST
   MIDI_DRIVER_SB_OUT
END_MIDI_DRIVER_LIST

BEGIN_DIGI_DRIVER_LIST
   DIGI_DRIVER_SB
END_DIGI_DRIVER_LIST

typedef struct
{
   WORD  xpos;
   WORD  ypos;
   WORD  unknown1;
   int   xgrid;
   int   ygrid;
   WORD  format;
   long  data_length;
   WORD  unknown2;
   long  data_offset;
   UBYTE * data;
} SUB_TILE_S;

typedef struct
{
   long       direction;
   WORD       unknown1;
   WORD       y_delta;
   long       ysize;
   long       xsize;
   long       zeros1;
   long       orientation;
   long       main_index;
   long       sub_index;
   long       frame;
   long       unknown2;
   int        sub_tiles_flags[32];
   long       tiles_ptr;
   long       tiles_length;
   long       tiles_number;
   int        zeros2[12];
   SUB_TILE_S * tile;
} BLOCK_S;

// global datas
PALETTE the_pal;
char    good_pal[768],
        tiles_path[256];
BLOCK_S * glb_block[32];
long    glb_block_number[32], dt1mask = 0;
int     glb_dt1_file = 0;
struct
{
   unsigned char p1;
   unsigned char p2;
   unsigned char p3;
   unsigned char p4;
} layer[12][128][128];


// ==========================================================================
// atexit() function, when the program end, to free the allocated memory
void ds1scene_exit(void)
{
   BLOCK_S     * block_ptr;
   SUB_TILE_S  * tile_ptr;
   int         b, t, i;

   for (i=0; i<32; i++)
   {
      if (glb_block[i] == NULL)
         return;
      for (b=0; b<glb_block_number[i]; b++)
      {
         block_ptr = glb_block[i] + b;
         if (block_ptr->tile != NULL)
         {
            for (t=0; t<block_ptr->tiles_number; t++)
            {
               tile_ptr = block_ptr->tile + t;
               if (tile_ptr->data != NULL)
                  free(tile_ptr->data);
            }
            free(block_ptr->tile);
         }
      }
      free(glb_block[i]);
   }
}


// ==========================================================================
// load a diablo 2 palette
void load_palette(char * d2pal)
{
   FILE * in;
   int  i, r, g, b;
   
   in = fopen(d2pal, "rb");
   if (in == NULL)
   {
      set_gfx_mode(GFX_TEXT, 80, 25, 0, 0);
      printf("\ncan't open palette : %s\n", d2pal);
      exit(1);
   }
   for (i=0; i<256; i++)
   {
      // order is BGR, not RGB
      b = fgetc(in);
      g = fgetc(in);
      r = fgetc(in);
      the_pal[i].b = b >> 2;
      the_pal[i].g = g >> 2;
      the_pal[i].r = r >> 2;
      good_pal[i*3]   = r;
      good_pal[i*3+1] = g;
      good_pal[i*3+2] = b;
      /*
         >> 2 is needed because the internal range of the RGB componants
         in allegro (8 bpp mode) is from 0 to 63 (because of the mode 13h),
         not 0 to 255. Since this program only output bitmaps for the purpose
         of tests, and don't create dt1 files, it's ok.
      */
   }

   // make a grey background
   the_pal[0].r = the_pal[0].g = the_pal[0].b = 24;
   good_pal[0]  = good_pal[1]  = good_pal[2]  = 96;
   fclose(in);
}


// ==========================================================================
// read the dt1 main header
void read_dt1_header(FILE * in, int block_idx)
{
   long x1, x2, fsize;
   int  i, c, is_dt1 = TRUE;

   // file size
   fseek(in, 0, SEEK_END);
   fsize = ftell(in);
   fseek(in, 0, SEEK_SET);
   
   // signature
   fread(&x1, 1, 4, in);
   fread(&x2, 1, 4, in);
   if ((x1 != 7) || (x2 != 6))
      is_dt1 = FALSE;
      
   // zeros
   for (i=0; i<260; i++)
   {
      c = fgetc(in);
      if (c != 0)
         is_dt1 = FALSE;
   }
   
   // # of blocks
   fread(&glb_block_number[block_idx], 1, 4, in);
   if (glb_block_number[block_idx] < 0)
   {
      fclose(in);
      printf("error : number of blocks is negative (%li)\n", glb_block_number[block_idx]);
      exit(1);
   }

   // start of block header, always 0x114
   fread(&x1, 1, 4, in);
   if (x1 != 0x114)
      is_dt1 = FALSE;
   if (x1 >= fsize)
   {
      fclose(in);
      printf("error : start of blocks (%li) >= size of file (%li)\n", x1, fsize);
      exit(1);
   }

   // summary
   if (is_dt1 != TRUE)
{
      printf("possibly not a dt1 file, stop\n");
      exit(1);
}

   // get mem for block headers
   glb_block[block_idx] = (BLOCK_S *) malloc(sizeof(BLOCK_S) * glb_block_number[block_idx]);
   if (glb_block[block_idx] == NULL)
   {
      fclose(in);
      printf("not enough memory for %li blocks header\n", glb_block_number[block_idx]);
      exit(1);
   }
   memset(glb_block[block_idx], 0, sizeof(BLOCK_S) * glb_block_number[block_idx]);

   // ready to read block headers
   fseek(in, x1, SEEK_SET);
}


// ==========================================================================
// read the blocks headers
void read_blocks_headers(FILE * in, int block_idx)
{
   BLOCK_S * block_ptr;
   int     h, i;

   block_ptr = glb_block[block_idx];
   for (h=0; h<glb_block_number[block_idx]; h++)
   {
      // direction
      fread(&block_ptr->direction, 1, 4, in);

      // y_delta
      fread(&block_ptr->y_delta, 1, 2, in);
      
      // unknown1
      fread(&block_ptr->unknown1, 1, 2, in);

      // ysize and xsize
      fread(&block_ptr->ysize, 1, 4, in);
      fread(&block_ptr->xsize, 1, 4, in);

      // zeros ?
      fread(&block_ptr->zeros1, 1, 4, in);
      
      // num[0] to num[3] (still unknown)
      fread(&block_ptr->orientation, 1, 4, in);
      fread(&block_ptr->main_index,  1, 4, in);
      fread(&block_ptr->sub_index,   1, 4, in);
      fread(&block_ptr->frame,       1, 4, in);

      // unknown 2 (always FF 00 FF 00 ?)
      fread(&block_ptr->unknown2, 1, 4, in);

      // sub-tiles flags (space for 32 max, but 25 in floor tiles)
      for (i=0; i<32; i++)
          block_ptr->sub_tiles_flags[i] = fgetc(in);

      // pointer to sub-tiles headers
      fread(&block_ptr->tiles_ptr,     1, 4, in);

      // sub-tiles length
      fread(&block_ptr->tiles_length,  1, 4, in);

      // # of sub-tiles (32 max ?)
      fread(&block_ptr->tiles_number,  1, 4, in);

      // zeros ?
      for (i=0; i<12; i++)
          block_ptr->zeros2[i] = fgetc(in);

      // ready to read next block header
      block_ptr++;
   }
}


// ==========================================================================
// read the sub-tiles of 1 block
void read_tiles_of_block(FILE * in, long b, int block_idx)
{
   BLOCK_S    * block_ptr;
   SUB_TILE_S * tile_ptr;
   UBYTE      * ptr;
   long       nb_tiles, t, f_pos;
   int        i;

   // get ready
   block_ptr = glb_block[block_idx] + b;
   nb_tiles = block_ptr->tiles_number;

   // reserve memory
   block_ptr->tile = (SUB_TILE_S *) malloc(sizeof(SUB_TILE_S) * nb_tiles);
   if (block_ptr->tile == NULL)
   {
      fclose(in);
      printf("in block %li, not enough memory for %li tiles\n", b, nb_tiles);
      exit(1);
   }
   memset(block_ptr->tile, 0, sizeof(SUB_TILE_S) * nb_tiles);

   // ready to read tiles header
   fseek(in, block_ptr->tiles_ptr, SEEK_SET);
   tile_ptr = block_ptr->tile;

   // read each of them
   for (t=0; t<nb_tiles; t++)
   {
      // xpos & ypos
      fread(&tile_ptr->xpos, 1, 2, in);
      fread(&tile_ptr->ypos, 1, 2, in);

      // unknwon 1
      fread(&tile_ptr->unknown1, 1, 2, in);

      // xgrid & ygrid
      tile_ptr->xgrid = fgetc(in);
      tile_ptr->ygrid = fgetc(in);

      // sub-tile format
      fread(&tile_ptr->format, 1, 2, in);

      // sub-tile data length
      fread(&tile_ptr->data_length, 1, 4, in);

      // unknown 2
      fread(&tile_ptr->unknown2, 1, 2, in);
      
      // sub-til data offset
      fread(&tile_ptr->data_offset, 1, 4, in);

      // ready to read next sub-tile
      tile_ptr++;
   }

   // after the sub-tiles headers, their datas
   
   // read data of each sub-tiles
   tile_ptr = block_ptr->tile;
   for (t=0; t<nb_tiles; t++)
   {
      // file pointer = start of sub-tiles header + sub-tile data offset
      f_pos = block_ptr->tiles_ptr + tile_ptr->data_offset;
      fseek(in, f_pos, SEEK_SET);

      // reserved memory for data
      tile_ptr->data = (UBYTE *) malloc(tile_ptr->data_length);
      if (tile_ptr->data == NULL)
      {
         fclose(in);
         printf("in block %li, sub-tile %li, not enough memory for %li bytes\n",
            b, t, tile_ptr->data_length);
         exit(1);
      }

      // read data
      ptr = tile_ptr->data;
      for (i=0; i<tile_ptr->data_length; i++)
      {
         * ptr = fgetc(in);
         ptr++;
      }

      // next sub-tile data
      tile_ptr++;
   }
}


// ==========================================================================
// draw a 3d-isometric sub-tile
void draw_sub_tile_isometric (BITMAP * dst, int x0, int y0, const UBYTE * data, int length)
{
   UBYTE * ptr = data;
   int   x, y=0, n,
         xjump[15] = {14, 12, 10, 8, 6, 4, 2, 0, 2, 4, 6, 8, 10, 12, 14},
         nbpix[15] = {4, 8, 12, 16, 20, 24, 28, 32, 28, 24, 20, 16, 12, 8, 4};

   // 3d-isometric subtile is 256 bytes, no more, no less
   if (length != 256)
      return;

   // draw
   while (length > 0)
   {
      x = xjump[y];
      n = nbpix[y];
      length -= n;
      while (n)
      {
         putpixel(dst, x0+x, y0+y, * ptr);
         ptr++;
         x++;
         n--;
      }
      y++;
   }
}


// ==========================================================================
// draw a normal sub-tile (can be transparent, so there are "jump" coded)
void draw_sub_tile_normal (BITMAP * dst, int x0, int y0, const UBYTE * data, int length)
{
   UBYTE * ptr = data, b1, b2;
   int   x=0, y=0;

   // draw
   while (length > 0)
   {
      b1 = * ptr;
      b2 = * (ptr + 1);
      ptr += 2;
      length -= 2;
      if (b1 || b2)
      {
         x += b1;
         length -= b2;
         while (b2)
         {
            putpixel(dst, x0+x, y0+y, * ptr);
            ptr++;
            x++;
            b2--;
         }
      }
      else
      {
         x = 0;
         y++;
      }
   }
}


// ==========================================================================
void draw_block_search1(BITMAP * dst, int x0, int y0, int sub_idx, int main_idx)
{
   BLOCK_S    * block_ptr;
   SUB_TILE_S * tile_ptr;
   UBYTE      * ptr;
   int        b, t, x, y, length, dt1;

   for (dt1=0; dt1<glb_dt1_file; dt1++)
   {
      for (b=0; b<glb_block_number[dt1]; b++)
      {
         block_ptr = glb_block[dt1] + b;
         if ( (block_ptr->sub_index   == sub_idx)  &&
              (block_ptr->orientation == 0)        &&
              (block_ptr->main_index  == main_idx)
            )
         {
            y0 -= block_ptr->y_delta;
            if ((block_ptr->orientation != 0) && (block_ptr->orientation != 15))
               y0 += 80;
            tile_ptr  = block_ptr->tile;
            for(t=0; t<block_ptr->tiles_number; t++)
            {
               length = tile_ptr->data_length;
               ptr    = tile_ptr->data;
               x      = tile_ptr->xpos;
               y      = tile_ptr->ypos;
               if (tile_ptr->format == 0x0001)
                  draw_sub_tile_isometric(dst, x0+x, y0+y, ptr, length);
               else
                  draw_sub_tile_normal(dst, x0+x, y0+y, ptr, length);
               tile_ptr++;
            }
            printf("-");
            return;
         }
      }
   }
   printf("!");
}


// ==========================================================================
void draw_block_search2(BITMAP * dst, int x0, int y0, int orient, int sub_idx, int main_idx)
{
   BLOCK_S    * block_ptr;
   SUB_TILE_S * tile_ptr;
   UBYTE      * ptr;
   int        b, t, x, y, length, dt1;

   for (dt1=0; dt1<glb_dt1_file; dt1++)
   {
      for (b=0; b<glb_block_number[dt1]; b++)
      {
         block_ptr = glb_block[dt1] + b;
         if ( (block_ptr->sub_index   == sub_idx)  &&
              (block_ptr->orientation == orient)   &&
              (block_ptr->main_index  == main_idx)
            )
         {
            y0 -= block_ptr->y_delta;
            if ((block_ptr->orientation != 0) && (block_ptr->orientation != 15))
               y0 += 80;
            tile_ptr  = block_ptr->tile;
            for(t=0; t<block_ptr->tiles_number; t++)
            {
               length = tile_ptr->data_length;
               ptr    = tile_ptr->data;
               x      = tile_ptr->xpos;
               y      = tile_ptr->ypos;
               if (tile_ptr->format == 0x0001)
                  draw_sub_tile_isometric(dst, x0+x, y0+y, ptr, length);
               else
                  draw_sub_tile_normal(dst, x0+x, y0+y, ptr, length);
               tile_ptr++;
            }
            switch(orient)
            {
               case  3 : break;
               case  4 : printf("+"); break;
               case 15 : printf("R"); break;
               default : printf("="); break;
            }
            return;
         }
      }
   }

   // not found, try with swapping orientation
   if ((orient == 18) || (orient == 19))
   {
      if (orient == 18)
         orient = 19;
      else if (orient == 19)
         orient = 18;
         
      for (dt1=0; dt1<glb_dt1_file; dt1++)
      {
         for (b=0; b<glb_block_number[dt1]; b++)
         {
            block_ptr = glb_block[dt1] + b;
            if ( (block_ptr->sub_index   == sub_idx)  &&
                 (block_ptr->orientation == orient)   &&
                 (block_ptr->main_index  == main_idx)
               )
            {
               y0 -= block_ptr->y_delta;
               if ((block_ptr->orientation != 0) && (block_ptr->orientation != 15))
                  y0 += 80;
               tile_ptr  = block_ptr->tile;
               for(t=0; t<block_ptr->tiles_number; t++)
               {
                  length = tile_ptr->data_length;
                  ptr    = tile_ptr->data;
                  x      = tile_ptr->xpos;
                  y      = tile_ptr->ypos;
                  if (tile_ptr->format == 0x0001)
                     draw_sub_tile_isometric(dst, x0+x, y0+y, ptr, length);
                  else
                     draw_sub_tile_normal(dst, x0+x, y0+y, ptr, length);
                  tile_ptr++;
               }
               switch(orient)
               {
                  case  3 : break;
                  case  4 : printf("+"); break;
                  case 15 : printf("R"); break;
                  case 18 :
                  case 19 : printf("W"); break;
                  default : printf("="); break;
               }
               return;
            }
         }
      }
   }

   // not found, try with sub_index = 0
   if ((orient == 18) || (orient == 19))
   {
      sub_idx = 0;
      
      for (dt1=0; dt1<glb_dt1_file; dt1++)
      {
         for (b=0; b<glb_block_number[dt1]; b++)
         {
            block_ptr = glb_block[dt1] + b;
            if ( (block_ptr->sub_index   == sub_idx)  &&
                 (block_ptr->orientation == orient)   &&
                 (block_ptr->main_index  == main_idx)
               )
            {
               y0 -= block_ptr->y_delta;
               if ((block_ptr->orientation != 0) && (block_ptr->orientation != 15))
                  y0 += 80;
               tile_ptr  = block_ptr->tile;
               for(t=0; t<block_ptr->tiles_number; t++)
               {
                  length = tile_ptr->data_length;
                  ptr    = tile_ptr->data;
                  x      = tile_ptr->xpos;
                  y      = tile_ptr->ypos;
                  if (tile_ptr->format == 0x0001)
                     draw_sub_tile_isometric(dst, x0+x, y0+y, ptr, length);
                  else
                     draw_sub_tile_normal(dst, x0+x, y0+y, ptr, length);
                  tile_ptr++;
               }
               switch(orient)
               {
                  case  3 : break;
                  case  4 : printf("+"); break;
                  case 15 : printf("R"); break;
                  case 18 :
                  case 19 : printf("W"); break;
                  default : printf("="); break;
               }
               return;
            }
         }
      }
   }
   
   if (orient == 3)
      printf("#");
   else if (orient == 4)
      printf("@");
   else
      printf("?");
}


// ==========================================================================
void draw_block_search3(BITMAP * dst, int x0, int y0, int orient, int sub_idx, int main_idx)
{
   BLOCK_S    * block_ptr;
   SUB_TILE_S * tile_ptr;
   UBYTE      * ptr;
   int        b, t, x, y, length, dt1;

   for (dt1=0; dt1<glb_dt1_file; dt1++)
   {
      for (b=0; b<glb_block_number[dt1]; b++)
      {
         block_ptr = glb_block[dt1] + b;
         if ( (block_ptr->sub_index   == sub_idx)  &&
              (block_ptr->orientation == orient)   &&
              (block_ptr->main_index  == main_idx)
            )
         {
            y0 -= block_ptr->y_delta;
            if ((block_ptr->orientation != 0) && (block_ptr->orientation != 15))
               y0 += 80;
            tile_ptr  = block_ptr->tile;
            for(t=0; t<block_ptr->tiles_number; t++)
            {
               length = tile_ptr->data_length;
               ptr    = tile_ptr->data;
               x      = tile_ptr->xpos;
               y      = tile_ptr->ypos;
               if (tile_ptr->format == 0x0001)
                  draw_sub_tile_isometric(dst, x0+x, y0+y, ptr, length);
               else
                  draw_sub_tile_normal(dst, x0+x, y0+y, ptr, length);
               tile_ptr++;
            }
            return;
         }
      }
   }
}


// ==========================================================================
void ds1scene_ini(void)
{
   FILE * in;
   char ininame[20] = "ds1scene.ini", line[256], tpath[20] = "tiles_path",
        tmp[256];
   int  i;

   in = fopen(ininame, "rt");
   if (in == NULL)
   {
      printf("can't open %s, created it, you have to edit it now\n", ininame);
      in = fopen(ininame, "wt");
      fputs("tiles_path = d:\\data\\global\\tiles\n", in);
      fclose(in);
      exit(1);
   }
   fgets(line, sizeof(line), in);
   if (strlen(line) > 0)
      line[strlen(line) - 1] = 0;
   fclose(in);
   for (i=0; i<strlen(tpath); i++)
   {
      if (line[i] != tpath[i])
      {
         printf("can't found \"%s\" in %s\n", tpath, ininame);
         exit(1);
      }
   }

   // equal
   while (line[i] != '=' && i < strlen(line))
      i++;
   if (line[i] != '=')
   {
      printf("can't found '=' after \"%s\" in %s\n", tpath, ininame);
      exit(1);
   }

   // spaces
   i++;
   while (line[i] == ' ' && i < strlen(line))
      i++;
   if (i >= strlen(line))
   {
      printf("can't found a path after \"%s = \" in %s\n", tpath, ininame);
      exit(1);
   }

   // found tiles path
   sprintf(tiles_path, "%s\\", & line[i]);
   printf("tiles_path = %s\n", tiles_path);
   sprintf(tmp, "%s.", tiles_path);
   if (__file_exists(tmp) == 0)
   {
      printf("the path \"%s\" in %s does not exist\n", tmp, ininame);
      exit(1);
   }
}


// ==========================================================================
void read_dt1mask(int def)
{
   FILE * in;
   char txt[20] = "dt1mask.txt", line[80], * ptr;
   int  ret, i, row[4], rownum, s;
   
   printf("dt1def = %i\n", def);
   in = fopen(txt, "rt");
   if (in == NULL)
   {
      printf("can't open %s\n", txt);
      exit(1);
   }

   ptr = fgets(line, sizeof(line), in); // skip 1st line
   while (ptr != NULL)
   {
      ptr = fgets(line, sizeof(line), in);
      s = strlen(line);
      if (s > 0)
      {
         line[s-1] = 0;
         s--;
      }
      row[0] = rownum = 0;
      for (i=0; i<s; i++)
      {
         if (line[i] == '\t')
         {
            line[i] = 0;
            rownum++;
            row[rownum] = i+1;
         }
      }
      if (atoi(line + row[1]) == def)
      {
         fclose(in);
         dt1mask = atol(line + row[2]);
         printf("dt1mask = %li\n", dt1mask);
         return;
      }
   }
   fclose(in);
   printf("couldn't found the dt1def %i in %s\n", def, txt);
   exit(1);
}


// ==========================================================================
int read_dt1files(int type)
{
   FILE * in;
   char txt[20] = "dt1files.txt", line[2048], * ptr, name[256];
   int  ret, i, row[36], rownum, s, t;
   
   printf("dt1type = %i\n", type);
   in = fopen(txt, "rt");
   if (in == NULL)
   {
      printf("can't open %s\n", txt);
      exit(1);
   }

   ptr = fgets(line, sizeof(line), in); // skip 1st line
   while (ptr != NULL)
   {
      ptr = fgets(line, sizeof(line), in);
      s = strlen(line);
      if (s > 0)
      {
         line[s-1] = 0;
         s--;
      }
      row[0] = rownum = 0;
      for (i=0; i<s; i++)
      {
         if (line[i] == '\t')
         {
            line[i] = 0;
            rownum++;
            row[rownum] = i+1;
         }
         else if (line[i] == '/')
            line[i] = '\\';
      }
      if (atoi(line + row[1]) == type)
      {
         fclose(in);
         printf("found dt1files :\n");
         glb_dt1_file = 0;
         for (i=0; i<32; i++)
         {
            sprintf(name, "%s%s", tiles_path, line + row[i + 3]);
            if (dt1mask & (1 << i))
            {
               in = fopen(name, "rb");
               if (in == NULL)
               {
                  printf("can't open %s\n", name);
                  exit(1);
               }
               else
                  printf("opening %s\n", name);
               read_dt1_header(in, glb_dt1_file);
               read_blocks_headers(in, glb_dt1_file);
               for (t=0; t<glb_block_number[glb_dt1_file]; t++)
                  read_tiles_of_block(in, t, glb_dt1_file);
               fclose(in);
               glb_dt1_file++;
            }
            else
            {
               if ( * (line + row[i + 3]) != '0')
                  printf("   (skip %s)\n", line + row[i + 3]);
            }
         }
         return atoi(line + row[2]); // act
      }
   }
   fclose(in);
   printf("couldn't found the dt1type %i in %s\n", type, txt);
   exit(1);
}


// ==========================================================================
void good_palette(char * name)
{
   FILE * in;
   int  i;

   in = fopen(name, "rb+");
   if (in == NULL)
   {
      printf("can't modify palette of file %s\n", name);
      exit(1);
   }

   fseek(in, -768, SEEK_END);
   for (i=0; i<768; i++)
      fputc(good_pal[i], in);
   fclose(in);
}


// ==========================================================================
void func_tmp(char * filename)
{
   FILE * in;
   int  t;
   char name[256], * ptr;
   
   ptr = strstr(filename, "tiles\\");
   if (ptr != NULL)
      ptr += 6;
   sprintf(name, "%s%s", tiles_path, ptr);
   in = fopen(name, "rb");
   if (in == NULL)
   {
      printf("can't open %s\n", name);
      exit(1);
   }
   else
      printf("opening %s\n", name);
   read_dt1_header(in, glb_dt1_file);
   read_blocks_headers(in, glb_dt1_file);
   for (t=0; t<glb_block_number[glb_dt1_file]; t++)
      read_tiles_of_block(in, t, glb_dt1_file);
   fclose(in);
   glb_dt1_file++;
}


// ==========================================================================
void search_wall_order(int * tab, int n, int h0, int h1, int h2, int h3)
{
   int loop, i, tmp, h[4];
   struct
   {
      int idx;
      int hei;
   } data[4];
   
   data[0].idx = * tab;
   data[0].hei = h0;

   data[1].idx = * (tab+1);
   data[1].hei = h1;
   
   data[2].idx = * (tab+2);
   data[2].hei = h2;

   data[3].idx = * (tab+3);
   data[3].hei = h3;

   for (loop=0; loop<n-1; loop++)
   {
      for (i=0; i<n-1; i++)
      {
         if (data[i].hei > data[i+1].hei)
         {
            // swap
            tmp = data[i].idx;
            data[i].idx = data[i+1].idx;
            data[i+1].idx = tmp;

            tmp = data[i].hei;
            data[i].hei = data[i+1].hei;
            data[i+1].hei = tmp;
         }
      }
   }

   * tab = data[0].idx;
   * (tab+1) = data[1].idx;
   * (tab+2) = data[2].idx;
   * (tab+3) = data[3].idx;
}


// ==========================================================================
int main(int argc, char * argv[])
{
   BITMAP * savebmp = NULL, * tmpbmp = NULL;
   FILE   * in;
   int    t, screen_x = 1024, screen_y = 768, c, maxlayer, pcx_w, pcx_h,
          xx, yy, base_x, base_y, prm_pal = FALSE, pal, l;
   long   x1, w, h, act, x2, f, i, x3, x4, x, y, n, wa_st, fl_st, x2_st;
   char   p1, p2, p3, p4, tmp[256], layermask[20], filename[256];
   int    nnn;
   int    wall_order[4];

   
   // allegro stuff
   allegro_init();
   set_color_depth(8);

   // init
   for (i=0; i<32; i++)
   {
      glb_block[i] = NULL;
      glb_block_number[i] = 0;
   }
   atexit(ds1scene_exit);
   
   // header & syntaxe
   printf("DS1SCENE v 0.61, by Paul Siramy, Freeware\n"
          "=========================================\n");
   ds1scene_ini();
   if (argc < 5)
   {
      printf("\nsyntaxe : ds1scene <file.pcx> <file.ds1> <dt1type> <dt1def> <layermask>\n\n"
             "   ex : ds1scene duriel_lair.pcx act2\\tomb\\duriel.ds1 17 481 0001\n"
             "   dt1type is in dt1files.txt\n"
             "   dt1def  is in dt1mask.txt\n");
      exit(0);
   }
   memset(layermask, '1', sizeof(layermask));
   if (argc == 6)
   {
      memset(layermask, '0', sizeof(layermask));
      for (i=0; i<strlen(argv[5]); i++)
         layermask[i] = * (argv[5] + i);
      layermask[19] = 0;
   }

   // txt
   sprintf(tmp, "debug_txt\\%s", argv[1]);
   tmp[strlen(tmp) - 4] = 0;
   strcat(tmp, ".txt");
   freopen(tmp, "wt", stdout);
   fprintf(stderr, "output redirected in %s\n", tmp);

   printf("layermask = %.32s\n", layermask);
   
   // dt1
   read_dt1mask(atoi(argv[4]));
   fprintf(stderr, "reading dt1...");
   pal = read_dt1files(atoi(argv[3]));
   fprintf(stderr, "done\n");

   // palette
   printf("palette act %i\n", pal);
   switch(pal)
   {
      case 1 : load_palette("d2pal\\act1.dat"); break;
      case 2 : load_palette("d2pal\\act2.dat"); break;
      case 3 : load_palette("d2pal\\act3.dat"); break;
      case 4 : load_palette("d2pal\\act4.dat"); break;
      case 5 : load_palette("d2pal\\act5.dat"); break;
      default : printf("unknown palette %i\n", pal);
   }

   // ds1 file
   sprintf(tmp, "%s%s", tiles_path, argv[2]);
   in = fopen(tmp, "rb");
   if (in == NULL)
   {
      printf("can't open %s\n", tmp);
      exit(1);
   }
   fread(&x1, 1, 4, in);
   printf("x1     = %li\n", x1);
   fread(&w, 1, 4, in);
   printf("width  = %li (+1 = %li)\n", w, w+1);
   fread(&h, 1, 4, in);
   printf("height = %li (+1 = %li)\n", h, h+1);
   if (x1 != 3)
   {
      fread(&act, 1, 4, in);
      printf("act    = %li ( = acte %li)\n", act, act+1);
   }
   else
      printf("no act data (x1 = 3)\n");
   if ((x1 != 3) && (x1 != 8))
   {
      fread(&x2, 1, 4, in);
      printf("x2     = %li\n", x2);
   }
   else
      printf("no x2 data (x1 = %i)\n", x1);
   fread(&f, 1, 4, in);
   printf("files  = %li\n", f);

   // skip files in ds1
   for (i=0; i<f; i++)
   {
      c = fgetc(in);
      while (c != 0)
         c = fgetc(in);
   }

   // continue
   if ((x1 != 3) && (x1 != 8))
   {
      fread(&x3, 1, 4, in);
      printf("x3     = %li\n", x3);
      fread(&x4, 1, 4, in);
      printf("x4     = %li\n", x4);
   }
   else
   {
      printf("no x3 & no x4 data (x1 = %i)\n", x1);
   }

   wa_st = 0;
   fl_st = wa_st + x3 * 2;
   x2_st = fl_st + x4;

   if (x2)
      maxlayer = x2 + (x3 * 2) + x4;
   else
      maxlayer = 1 + x2 + (x3 * 2) + x4;
      
   printf("layer_to_read = %i\n", maxlayer);
   memset(layer, 0, 4 * 12 * 128 * 128);
   for (i=0; i < maxlayer; i++)
   {
      for (y=0; y<h+1; y++)
      {
         for (x=0; x<w+1; x++)
         {
            layer[i][y][x].p1 = fgetc(in);
            layer[i][y][x].p2 = fgetc(in);
            layer[i][y][x].p3 = fgetc(in);
            layer[i][y][x].p4 = fgetc(in);
         }
      }
   }
   fclose(in);

   // ds1 layer draw
   pcx_w = 80 * ((w+1) + (h+1));
   pcx_h = 40 * ((w+1) + (h+1));
   printf("pcx = %i * %i\n", pcx_w, pcx_h);
   tmpbmp = create_bitmap(pcx_w, pcx_h);
   clear(tmpbmp);


   // rule
   printf("      ");
   for (x=0; x<w+1; x++)
   {
      for (l=0; l<x4; l++) // floors
         printf("%01i", (x/100) % 10);
      for (l=0; l<x3*2; l++) // lower & upper walls
         printf("%01i", (x/100) % 10);
      printf("|");
   }
   printf("\n");
   
   printf("      ");
   for (x=0; x<w+1; x++)
   {
      for (l=0; l<x4; l++)
         printf("%01i", (x/10) % 10);
      for (l=0; l<x3*2; l++)
         printf("%01i", (x/10) % 10);
      printf("|");
   }
   printf("\n");
   
   printf("      ");
   for (x=0; x<w+1; x++)
   {
      for (l=0; l<x4; l++)
         printf("%01i", x % 10);
      for (l=0; l<x3*2; l++)
         printf("%01i", x % 10);
      printf("|");
   }
   printf("\n");
   

   // draw
   for (y=0; y<h+1; y++)
   {
      printf("%3i : ", y);
      fprintf(stderr, "line %3i\n", y);
      base_x = (80 * h) - (80 * y);
      base_y = 40 * y;
      for (x=0; x<w+1; x++)
      {
         xx = base_x + (80 * x);
         yy = base_y + (40 * x);

         // lower walls
         wall_order[0] = 0;
         wall_order[1] = 1;
         wall_order[2] = 2;
         wall_order[3] = 3;
         search_wall_order(& wall_order, x3, layer[(wa_st)*2][y][x].p1,
                                             layer[(wa_st+1)*2][y][x].p1,
                                             layer[(wa_st+2)*2][y][x].p1,
                                             layer[(wa_st+3)*2][y][x].p1);
         for (l=0; l<x3; l++)
         {
            if (layermask[wall_order[l]] != '1')
            {
               printf(" ");
               continue;
            }
            else if (layer[(wa_st+wall_order[l])*2][y][x].p4 & 0x80) // binary : 1000-0000
            {
               printf("B");
               continue;
            }
            else if (layer[(wa_st+wall_order[l])*2+1][y][x].p1 <= 15)
            {
               printf(" ");
               continue; // none, or upper walls & roofs later
            }
            else // > 15
            {
               draw_block_search2(tmpbmp, xx, yy,
                  layer[(wa_st+wall_order[l])*2+1][y][x].p1,              // orientation
                  layer[(wa_st+wall_order[l])*2][y][x].p2,                // sub-index
                  (layer[(wa_st+wall_order[l])*2][y][x].p3 / 16) +        // main-index
                  ((layer[(wa_st+wall_order[l])*2][y][x].p4 & 0x0F) * 16) // main-index
               );
            }
         }

         // floors
         for (l=0; l<x4; l++)
         {
            if (layermask[x3+l] != '1')
            {
               printf(" ");
               continue;
            }
            else if (layer[fl_st+l][y][x].p1 > 0)
            {
               draw_block_search1(tmpbmp, xx, yy,
                  layer[fl_st+l][y][x].p2,                // sub-index
                  (layer[fl_st+l][y][x].p3 / 16) +        // main-index
                  ((layer[fl_st+l][y][x].p4 & 0x0F) * 16) // main-index
               );
            }
            else
               printf(" ");
         }

         // upper walls
         wall_order[0] = 0;
         wall_order[1] = 1;
         wall_order[2] = 2;
         wall_order[3] = 3;
         search_wall_order(& wall_order, x3, layer[(wa_st)*2][y][x].p1,
                                             layer[(wa_st+1)*2][y][x].p1,
                                             layer[(wa_st+2)*2][y][x].p1,
                                             layer[(wa_st+3)*2][y][x].p1);
         for (l=0; l<x3; l++)
         {
            if (layermask[wall_order[l]] != '1')
            {
               printf(" ");
               continue;
            }
            else if (layer[(wa_st+wall_order[l])*2][y][x].p4 & 0x80) // binary : 1000-0000
            {
               printf("B");
               continue;
            }
            else if (layer[(wa_st+wall_order[l])*2+1][y][x].p1 == 15)
            {
               printf("R");
               continue; // roofs later
            }
            else if (layer[(wa_st+wall_order[l])*2+1][y][x].p1 > 15)
            {
               printf(" ");
               continue; // lower walls already draw
            }
            else if ( (layer[(wa_st+wall_order[l])*2+1][y][x].p1 > 0))
            {
               if (layer[(wa_st+wall_order[l])*2+1][y][x].p1 == 3)
               {
                  draw_block_search2(tmpbmp, xx, yy,
                     3,                                          // orientation
                     layer[(wa_st+wall_order[l])*2][y][x].p2,                // sub-index
                     (layer[(wa_st+wall_order[l])*2][y][x].p3 / 16) +        // main-index
                     ((layer[(wa_st+wall_order[l])*2][y][x].p4 & 0x0F) * 16) // main-index
                  );
               
                  draw_block_search2(tmpbmp, xx, yy,
                     4,                                          // orientation
                     layer[(wa_st+wall_order[l])*2][y][x].p2,                // sub-index
                     (layer[(wa_st+wall_order[l])*2][y][x].p3 / 16) +        // main-index
                     ((layer[(wa_st+wall_order[l])*2][y][x].p4 & 0x0F) * 16) // main-index
                  );
               }
               else // not upper / left corner
               {
                  draw_block_search2(tmpbmp, xx, yy,
                     layer[(wa_st+wall_order[l])*2+1][y][x].p1,              // orientation
                     layer[(wa_st+wall_order[l])*2][y][x].p2,                // sub-index
                     (layer[(wa_st+wall_order[l])*2][y][x].p3 / 16) +        // main-index
                     ((layer[(wa_st+wall_order[l])*2][y][x].p4 & 0x0F) * 16) // main-index
                  );
               }
            }
            else
               printf(" ");
         }

/*
         // unknown layer (x2)
         for (l=0; l<x2; l++)
         {
            if ((layer[x2_st+l][y][x].p1 > 0))
            {
               draw_block_search1(tmpbmp, xx, yy,
                  layer[x2_st+l][y][x].p2,                // sub-index
                  (layer[x2_st+l][y][x].p3 / 16) +        // main-index
                  ((layer[x2_st+l][y][x].p4 & 0x0F) * 16) // main-index
               );
            }
            else
               printf(" ");
         }
*/
         printf("|");
      }
      printf("\n");
   }
   
   // roofs
   for (y=0; y<h+1; y++)
   {
      fprintf(stderr, "roof line %3i\n", y);
      base_x = (80 * h) - (80 * y);
      base_y = 40 * y;
      for (x=0; x<w+1; x++)
      {
         xx = base_x + (80 * x);
         yy = base_y + (40 * x);
         
         // roofs
         for (l=0; l<x3; l++)
         {
            if (layermask[l] != '1')
               continue;
            else if (layer[(wa_st+l)*2][y][x].p4 & 0x80) // binary : 1000-0000
               continue;
            else if (layer[(wa_st+l)*2+1][y][x].p1 == 15)
            {
               draw_block_search3(tmpbmp, xx, yy,
                  15,                                         // orientation
                  layer[(wa_st+l)*2][y][x].p2,                // sub-index
                  (layer[(wa_st+l)*2][y][x].p3 / 16) +        // main-index
                  ((layer[(wa_st+l)*2][y][x].p4 & 0x0F) * 16) // main-index
               );
            }
         }
      }
   }

   // end
   fprintf(stderr, "saving pcx...");
   save_pcx(argv[1], tmpbmp, &the_pal);
   good_palette(argv[1]);
   fprintf(stderr, "done\n");
   destroy_bitmap(tmpbmp);
   return 0;
}

