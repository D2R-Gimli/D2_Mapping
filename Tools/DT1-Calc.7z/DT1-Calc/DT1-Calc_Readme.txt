 DT1-Calc.v.1.0 by Cubaholic with help from Crazy L'imon
 =======================================================
 Description:
 This program allows you:
 1) to calculate dt1 mask;
 2) to get numbers of the tile-sets, which were used 
 for calculation of any dt1mask.
 =======================================================
 How to use:
 >If you want to calculate dt1 mask:
 1) set the tile-sets you want to use in your ds1;
 2) Press "Calculate Mask".
 >If you want to get numbers of tile-sets, 
 which were used for calculation of any dt1mask:
 1) Type the dt1-mask-value 
 2) Press "Calculate Tile-Sets"
 =======================================================
 Any questions or comments send to Crazy L'imon
 with the Private Message (Phrozen-Keep)
 http://phrozenkeep.planetdiablo.gamespy.com/forum/privmsg.php?mode=post&u=18979